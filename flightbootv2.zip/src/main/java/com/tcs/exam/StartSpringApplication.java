package com.tcs.exam;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartSpringApplication {

    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(StartSpringApplication.class, args);
    }

}
